# ESP-12 breakout board

---
A simple ESP-12 breakout board for development and deployment.

![Top](/top.png)

![Bottom](/bottom.png)


see [logs](https://hackaday.io/project/13018-esp-12e-breakout-board)

[Cern Open Hardware v1.2 Licence](http://www.ohwr.org/attachments/2388/cern_ohl_v_1_2.txt)