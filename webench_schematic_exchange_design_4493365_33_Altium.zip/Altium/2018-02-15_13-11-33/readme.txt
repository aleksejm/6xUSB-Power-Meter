 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: Z:\\44\\93\\4493365\\33\Altium\2018-02-15_13-11-33\2018-02-15_13-11-33
 
 
**********************************************************
***************** Schematic Instructions  ****************
**********************************************************

To import your new Schematic into Altium:

1. Unzip the downloaded folder files to a local directory and
Start the Altium program.
2. From the menu select "File"->"Open".
3. Select the file named in the path above ending with ".schdoc"
and "Open" the file.
4. Your Schematic should be viewable within Altium now.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_BrdSch_import.html



**********************************************************
*******************  PCB Instructions  *******************
**********************************************************


To import your new BOARD into Altium:

1. Unzip the downloaded folder files to a local directory
	and Start the Altium program.
2. From the menu select "File"->"Open".
3. Select the file named in the path above ending with ".pcbdoc"
and "Open" the file.
4. Planes will need to be repoured to update the Copper Pour Polygons
	a. Once your board is loaded, select the Tools menu from the
	   top Menu Bar
	b. Scroll to the Polygon Pours item on the Tools Menu.
	c. The Polygon Pours item should expand to show more options
	d. Select Repour All Polygons, this will repour all of the
	   polygons.
5. Your board should be viewable within Altium now.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_BrdSch_import.html

**********************************************************
*******************  LIB Instructions  *******************
**********************************************************

To import your new LIBRARY PARTS into Altium follow these steps:

1. After running the Ultra Librarian export for the first time,
you will need to copy the following files into an area where
they can be accessed for all future translations.  They are script
files that Altium will need to be able to find.
	a. UL_Form.dfm
	b. UL_Form.pas
	c. UL_Import.pas
	d. UL_Import.prjScr
2. The above script file will need to be run from within Altium.
This can be done by going to File, Open and selecting the
UL_Import.PrjScr file stored above.
3. Select the "DXP" dropdown menu in the top-left corner runfrom
the drop down menu and select "Run Script". Select "UL_Form.pas"
and click "OK"
4. When the script is run, it will ask you for the file name of the
Ultra Librarian file to run. Click "File...", select the latest file
produced with a date code (for instance 2010-02-17_23-12-34.txt), and
click "Start Import".
5. The script will open a new Integraged Library project and import
the Ultra Librarian data into it.  When complete a message box
will pop up saying that import is done.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_import.html

For a video tutorial, please visit:
http://youtu.be/pih50yx9HYU

**********************************************************
**********************************************************
**********************************************************
 
 
Symbol "WB_PWL_VOLTAGE_SOURCE" renamed to "WB_PWL_VOLTAGE_S"
Symbol "WB_SOURCE_RESISTOR" renamed to "WB_SOURCE_RESIST"
Symbol "WB_PRIM_PWL_VOLTAGE_SOURCE" renamed to "WB_PRIM_PWL_VOLT"
Symbol "WB_PRIM_STARTUP_VOLTAGE_SOURCE" renamed to "WB_PRIM_STARTUP_"
Symbol "WB_STARTUP_VOLTAGE_SOURCE" renamed to "WB_STARTUP_VOLTA"
Symbol "WB_PWL_CURRENT_LOAD" renamed to "WB_PWL_CURRENT_L"
Symbol "WB_PRIMITIVE_BATTERY" renamed to "WB_PRIMITIVE_BAT"
Component "C0805C471K5RACTU" renamed to "C0805C471K5RACTU"
Component "ECPU1C684MA5" renamed to "ECPU1C684MA5"
Component "08055C104MAT2A" renamed to "08055C104MAT2A"
Component "WB_CURRENT_LOAD" renamed to "WB_CURRENT_LOAD"
Component "6SVPE220MW" renamed to "6SVPE220MW"
Component "C2012C0G1H153J085AA" renamed to "C2012C0G1H153J08"
Component "ECPU1C105MA5" renamed to "ECPU1C105MA5"
Component "WB_GND" renamed to "WB_GND"
Component "XAL1010-222MEB" renamed to "XAL1010-222MEB"
Component "CSD18504Q5A" renamed to "CSD18504Q5A"
Component "CSD18531Q5A" renamed to "CSD18531Q5A"
Component "RR1220P-103-D" renamed to "RR1220P-103-D"
Component "ERJ-6ENF7322V" renamed to "ERJ-6ENF7322V"
Component "ERJ-6ENF2051V" renamed to "ERJ-6ENF2051V"
Component "ERJ-6ENF1073V" renamed to "ERJ-6ENF1073V"
Component "LM3150MH/NOPB" renamed to "LM3150MH/NOPB"
Component "WB_BATTERY" renamed to "WB_BATTERY"
Component "C2012X5R1V226M125AC" renamed to "C2012X5R1V226M12"
The Symbol WB_CONTINUATION was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CONTINUATION was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CONTINUATION was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CFF_BLOCK was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CFF_BLOCK was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CFF_BLOCK was missing a Value attribute, a value was created for the symbol.
The Symbol WB_BLOCK_IO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_N_MOSFET was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_N_MOSFET was missing a Type attribute, a type was created for the symbol.
The Symbol WB_N_MOSFET was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LM3150 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LM3150 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LM3150 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a Value attribute, a value was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a Type attribute, a type was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a Value attribute, a value was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a Type attribute, a type was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.1.204 Process Report


Message - Symbol "WB_CAPACITOR" has as multiple attributes named "TYPE".
One of the attributes was renamed to "TYPE_2".
Message - Component "C0805C471K5RACTU" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C471K5RACTU" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C471K5RACTU" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C471K5RACTU" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ECPU1C684MA5" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ECPU1C684MA5" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ECPU1C684MA5" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ECPU1C684MA5" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ECPU1C684MA5" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "08055C104MAT2A" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "08055C104MAT2A" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "08055C104MAT2A" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "08055C104MAT2A" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "6SVPE220MW" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "6SVPE220MW" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "6SVPE220MW" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "6SVPE220MW" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "6SVPE220MW" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012C0G1H153J08" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012C0G1H153J08" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012C0G1H153J08" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012C0G1H153J08" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012C0G1H153J08" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ECPU1C105MA5" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ECPU1C105MA5" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ECPU1C105MA5" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ECPU1C105MA5" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ECPU1C105MA5" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "XAL1010-222MEB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "XAL1010-222MEB" attribute "L" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "XAL1010-222MEB" attribute "DCR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "XAL1010-222MEB" attribute "IDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18504Q5A" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18504Q5A" attribute "VdsMax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18504Q5A" attribute "IdsMax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18504Q5A" attribute "Rdson45" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18504Q5A" attribute "QgTyp" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18504Q5A" attribute "Quantity" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18531Q5A" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18531Q5A" attribute "VdsMax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18531Q5A" attribute "IdsMax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18531Q5A" attribute "Rdson45" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18531Q5A" attribute "QgTyp" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18531Q5A" attribute "Quantity" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RR1220P-103-D" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RR1220P-103-D" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RR1220P-103-D" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF7322V" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF7322V" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF7322V" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF2051V" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF2051V" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF2051V" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1073V" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1073V" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1073V" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM3150MH/NOPB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM3150MH/NOPB" attribute "Frequency" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM3150MH/NOPB" attribute "Imax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM3150MH/NOPB" attribute "Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM3150MH/NOPB" attribute "Mktg_Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM3150MH/NOPB" attribute "NSID" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V226M12" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V226M12" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V226M12" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V226M12" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V226M12" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.

TextStyle count:  24
Padstack count:   9
Pattern count:    7
Symbol count:     25
Component count:  18

Export

Footprint "0805" has no layer data mapped and will be skipped.
Component "C0805C471K5RACTU" requires footprint "0805" and will be skipped.
Component "08055C104MAT2A" requires footprint "0805" and will be skipped.
Component "C2012C0G1H153J08" requires footprint "0805" and will be skipped.
Component "RR1220P-103-D" requires footprint "0805" and will be skipped.
Component "ERJ-6ENF7322V" requires footprint "0805" and will be skipped.
Component "ERJ-6ENF2051V" requires footprint "0805" and will be skipped.
Component "ERJ-6ENF1073V" requires footprint "0805" and will be skipped.
Component "C2012X5R1V226M12" requires footprint "0805" and will be skipped.
Warning: Symbol "WB_CAPACITOR" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "PN" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "DEV" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "VAL" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "TOL" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "L" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "DCR" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "IDC" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "CSD18504Q5A" attribute "PN" references missing text style ""
Warning: Symbol "CSD18504Q5A" attribute "DEV" references missing text style ""
Warning: Symbol "CSD18504Q5A" attribute "VAL" references missing text style ""
Warning: Symbol "CSD18504Q5A" attribute "TOL" references missing text style ""
Warning: Symbol "CSD18504Q5A" attribute "RefDes2" references missing text style ""
Warning: Symbol "CSD18531Q5A" attribute "PN" references missing text style ""
Warning: Symbol "CSD18531Q5A" attribute "DEV" references missing text style ""
Warning: Symbol "CSD18531Q5A" attribute "VAL" references missing text style ""
Warning: Symbol "CSD18531Q5A" attribute "TOL" references missing text style ""
Warning: Symbol "CSD18531Q5A" attribute "RefDes2" references missing text style ""
Warning: Symbol "LM3150MH" attribute "PN" references missing text style ""
Warning: Symbol "LM3150MH" attribute "DEV" references missing text style ""
Warning: Symbol "LM3150MH" attribute "VAL" references missing text style ""
Warning: Symbol "LM3150MH" attribute "TOL" references missing text style ""
Warning: Symbol "LM3150MH" attribute "RefDes2" references missing text style ""
